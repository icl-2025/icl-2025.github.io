void m() { if (;) ; }
