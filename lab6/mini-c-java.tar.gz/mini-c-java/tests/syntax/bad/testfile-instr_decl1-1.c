void m() { int x = 0 }
