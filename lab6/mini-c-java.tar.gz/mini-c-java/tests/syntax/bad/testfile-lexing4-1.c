void m() { i/**/nt i = 10; }
