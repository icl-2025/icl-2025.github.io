
struct S { int a; };
int main() { int x; x->a; }
