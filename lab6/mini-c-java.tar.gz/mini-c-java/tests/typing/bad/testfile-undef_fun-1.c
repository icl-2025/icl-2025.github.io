int main() {
  f(1);
}
