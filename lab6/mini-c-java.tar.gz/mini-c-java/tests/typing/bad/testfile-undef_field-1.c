struct S {
  int a;
};

int main() {
  struct S* p;
  p->b = 1;
}

