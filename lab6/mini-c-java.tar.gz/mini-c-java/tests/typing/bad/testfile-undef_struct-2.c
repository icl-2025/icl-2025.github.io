
int f(struct A *s) { return 0; }
int main() { return 0; }
