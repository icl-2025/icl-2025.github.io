
int f() {}
int f(int x) {}
int main() {}
