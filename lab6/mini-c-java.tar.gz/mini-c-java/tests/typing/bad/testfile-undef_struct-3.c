
int main(){ struct B *a; return 0; }
