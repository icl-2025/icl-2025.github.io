
int f(){ g(); return 0; }
int g(){ return 0; }
int main() { f(); g(); return 0; }

