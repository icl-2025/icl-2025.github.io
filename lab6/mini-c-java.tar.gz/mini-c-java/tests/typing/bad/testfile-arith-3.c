
struct S { int a; };
int main() { int p; struct S *q; putchar(p-q); }

