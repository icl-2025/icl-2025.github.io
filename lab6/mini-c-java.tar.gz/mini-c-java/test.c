// mini-C example file
// to be completed as needed
//
// command 'make' recompiles mini-c (if needed)
// and runs on this file

int main() {
  return 0;
}
