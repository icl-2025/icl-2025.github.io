
struct S { int a; int a; };
int main() {}
