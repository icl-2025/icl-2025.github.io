
struct A { struct B *b; };
int main(){ return 0; }

