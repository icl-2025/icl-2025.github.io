
struct S { int a; };
int main() { struct S *p; 1-p; }
