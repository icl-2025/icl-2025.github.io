int main() { x; }
