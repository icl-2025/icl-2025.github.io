struct A* f() { return 0; }
int main() { return 0; }
