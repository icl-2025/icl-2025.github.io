void f() { { }
