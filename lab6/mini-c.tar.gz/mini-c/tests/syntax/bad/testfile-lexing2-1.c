void m() { int i = 1/// comment starts at first /, not second
        1; }
