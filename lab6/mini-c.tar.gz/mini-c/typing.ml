

(* The goal is to transform the abstract syntax tree obtained from the Parser
   (Ptree.file) into a typed abstract syntax tree (Ttree.file).
   That is, (as stated in the typing.mli interface file) we want to implement
   a function val program: debug:bool -> Ptree.file -> Ttree.file *)

(* Prior to completing this lab, please read carefully and get familiar with:
   - the accompanying PDF describing the syntax and static typing of mini-C
   - Parsed Abstract Syntax Tree interface (Ptree.file)
   - Typed Abstract Tree interface (Ptree.file)
   - OCaml: manipulating List, Hashtbl, and Map.Make(String) modules,
     in particular List.iter, List.fold_left, etc. Also Pay attention to the
     fact that Hashtbl.t is a mutable type while Maps are immutable.
*)


(* -------------------------------------------------------------------------- *)
(* ----    Part 0.0. Utilities: exceptions, type equivalence, etc.      ----- *)
(* -------------------------------------------------------------------------- *)

(* We start by opening the typed expressions. *)
open Ttree

(* We define string representation for each type. *)
let string_of_type = function
  | Tint       -> "int"
  | Tstructp x -> "struct " ^ x.str_name ^ " *"
  | Tvoidstar  -> "void*"

(* We declare various typing errors that we want to detect during
   the type-checking phase. *)
exception Error of Ptree.loc option * string

let error ?loc s = raise (Error (loc, s))
let unbound_var x = error ("unbound variable " ^ x)
let unbound_fun x = error ("unbound function " ^ x)
let unbound_struct x = error ("unbound structure " ^ x)
let duplicated_field x = error ("duplicate " ^ x)
let incompatible_types t1 t2 =
  error ("incompatible types " ^
	 string_of_type t1 ^ " and " ^ string_of_type t2)
let bad_arity ?loc p a =
  error ?loc ("bad arity: function p expects " ^
              string_of_int a ^ " arguments")

(* We also define function val unique : string -> string
   that generates variables with fresh names using an internal counter.
   E.g. the 10-th call to 'unique "x" will return "x__10". *)
let unique =
  let r = ref 0 in fun s -> incr r; s ^ "__" ^ string_of_int !r

(* -------------------------------------------------------------------------- *)
(* --  Part 0.1. Global (struct, fun) and local (var) typing environments  -- *)
(* -------------------------------------------------------------------------- *)

(* We will use hash tables to represent global typing environments to
   typecheck declared structures and functions and we will use Maps
   to represent local (variable) typing environments.
   That is, in the description PDF we use the same Gamma to denote typing
   enviroments, but in actual implementation we will split Gamma into
   those three typing environments (global structs type declarations, global
   functions type declarations, local variable types).
*)

(* First, we define an hash table to keep track of declared structures
   and an hash table to keep track of declared functions. *)
let structures = Hashtbl.create 17
let funs = Hashtbl.create 17

(* That is,
   - `structures` table will associate a name of the structure `x`
      with Ttree.structure, i.e. with a value of type
      { str_name = x;
        str_size = "length of fields";
        str_fields = "hash table from field names to field types"  }
   - `funs` table will associate a name of the function `f` with
      with its return type, and the types of formal parameters. *)

(* We start by adding predefined functions into funs environment: *)
let () =
  Hashtbl.add funs "putchar" ("putchar", Tint, [Tint, "x"]);
  Hashtbl.add funs "malloc" ("malloc", Tvoidstar, [Tint, "x"])

(* and we can check if the function id is already added to the table: *)
let is_global id =
  Hashtbl.mem funs id

(* Finally, we define the OCaml type of typing environments `ty_env` that
   associates variable names with pairs of their types and their unique representation
   (which is needed to typecheck local variables inside a single block). *)
module Env = Map.Make(String)
type typ_env = (Ttree.typ * string) Env.t

let ident env x =
  try Env.find x env
  with Not_found -> unbound_var x

(** Exercise 0. Implement the type equivalence relation
   val eq_type: Ttree.typ -> Ttree.typ -> bool *)
let eq_type t1 t2 = assert false (* TODO *)

(* Auxiliary function processing function and struct declarations
   and adding the result of typing phase to the accumulator acc. *)
let decl acc = function
  | Ptree.Dstruct s ->
      assert false (* TODO *)
  | Ptree.Dfun f ->
      assert false (* TODO *)

let is_main f = f.fun_name = "main"

(* Main Typing function. *)
let program ~debug p =
  let fl = List.fold_left decl [] p in
  if not (debug || List.exists is_main fl)
  then error "missing main function";
  { funs = fl }
