
(* Main file of mini-c compiler *)

open Format
open Lexing

let parse_only = ref false
let type_only = ref false
let debug = ref false

let ifile = ref ""
let set_file s = ifile := s

let options =
  ["--parse-only", Arg.Set parse_only,
     "  stops after parsing";
   "--type-only", Arg.Set type_only,
     "  stops after typing";
   "--debug", Arg.Set debug,
     "  debug mode";
   ]

let usage = "usage: mini-c [options] file.c"

let localisation pos =
  let l = pos.pos_lnum in
  let c = pos.pos_cnum - pos.pos_bol + 1 in
  eprintf "File \"%s\", line %d, characters %d-%d:\n" !ifile l (c-1) c

let () =
  Arg.parse options set_file usage;
  if !ifile="" then begin eprintf "missing file\n@?"; exit 1 end;
  if not (Filename.check_suffix !ifile ".c") then begin
    eprintf "file must have extension .c\n@?";
    Arg.usage options usage;
    exit 1
  end;
  let debug = !debug in
  let f = open_in !ifile in
  let buf = Lexing.from_channel f in
  try
    let p = Parser.file Lexer.token buf in
    close_in f;
    if !parse_only then exit 0;
    let _p = Typing.program ~debug p in
    if !type_only then exit 0;
  with
    | Lexer.Lexical_error c ->
	localisation (Lexing.lexeme_start_p buf);
	eprintf "lexical error: %s@." c;
	exit 1
    | Parser.Error ->
	localisation (Lexing.lexeme_start_p buf);
	eprintf "syntax error@.";
	exit 1
    | Typing.Error (loc, s) ->
       (match loc with Some (loc, _) -> localisation loc | None -> ());
	eprintf "typing error: %s@." s;
	exit 1
    | e when not debug ->
	eprintf "anomaly: %s\n@." (Printexc.to_string e);
	exit 2
