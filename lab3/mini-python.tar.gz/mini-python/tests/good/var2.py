x = "foo"
print(x)
