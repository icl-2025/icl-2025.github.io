package mini_python;

class Compile {

  static boolean debug = false;

  static X86_64 file(TFile f) {
    return null; // TODO
  }

}
