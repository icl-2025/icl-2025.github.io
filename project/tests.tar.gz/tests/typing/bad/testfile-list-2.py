
print(list(1))
