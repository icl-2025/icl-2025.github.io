def f(x):
    toto
  tata

