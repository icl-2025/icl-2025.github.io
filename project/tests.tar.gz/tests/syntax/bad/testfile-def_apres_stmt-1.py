1
def a () : 1


