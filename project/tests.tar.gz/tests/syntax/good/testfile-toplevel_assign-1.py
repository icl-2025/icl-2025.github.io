x = 4
print(x)

