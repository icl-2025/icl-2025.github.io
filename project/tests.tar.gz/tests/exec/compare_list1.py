# true
print([]     == [])
print([]     <  [1])
print([1]    != [2])
print([2, 1] <  [4, 1])
print([4]    <= [4, 6])
# false
print([5]    <= [])
