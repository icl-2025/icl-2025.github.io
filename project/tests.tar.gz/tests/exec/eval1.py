l = [1,2,3]
for x in l:
    l = []
    print(x)
