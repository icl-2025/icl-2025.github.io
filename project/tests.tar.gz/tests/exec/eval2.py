def f(n):
    print(n)
    return list(range(n))

for x in f(3):
    print(x)
