open Ast
open Interp

let rec fact x =
  if x = 0 then 1
  else x * fact (x - 1)

let x = "x"
let y = "y"
let r = "r"

let var_x = EVar x
let var_y = EVar y
let var_r = EVar r

let vint x = VInt x

let pair x y = EPair (x, y)
let fst x = EFst x
let snd x = ESnd x

let repeat s e = SRepeat (s, e)
let seq s1 s2 = SSeq (s1, s2)
let assign x e = SAssign (x, e)

let one = EValue (vint 1)
let zero = EValue (vint 0)
let five = EValue (vint 5)

let rec block = function
  | [] -> assert false
  | [s] -> s
  | s1 :: r ->
    let s = block r in
    seq s1 s

let mul e1 e2 = EBinop (e1, OMul, e2)
let sub e1 e2 = EBinop (e1, OSub, e2)
let eq e1 e2 = EBinop (e1, OEq, e2)

let repeat_body = block [
  assign x (fst var_r);
  assign y (snd var_r);
  assign y (mul var_y var_x);
  assign x (sub var_x one);
  assign r (pair var_x var_y);
]

let repeat_test = eq (fst var_r) zero

let p =
  seq (assign r (pair five one)) (repeat repeat_body repeat_test)

let () =
  let env = create () in
  stmt env p;
  match get env r with
  | VPair (VInt v1, VInt v2) ->
    assert (v1 = 0);
    assert (v2 = fact 5)
  | _ -> assert false
  | exception Not_found -> assert false
