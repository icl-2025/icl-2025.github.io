open Ast

type env = (string, value) Hashtbl.t
let get h x   = Hashtbl.find h x
let set h x v = Hashtbl.add h x v
let create () : env = Hashtbl.create 16

let interp_binop_arith v1 v2 op =
  match v1, v2 with
  | VInt v1, VInt v2 ->
    begin match op with
      | OAdd -> VInt (v1 + v2)
      | OMul -> VInt (v1 * v2)
      | OSub -> VInt (v1 - v2)
      | ODiv -> VInt (v1 / v2)
      | OMod -> VInt (v1 mod v2)
      | OEq -> VBool (v1 = v2)
      | ONeq -> VBool (v1 <> v2)
      | OLt -> VBool (v1 < v2)
      | OLe -> VBool (v1 <= v2)
      | OGt -> VBool (v1 > v2)
      | OGe -> VBool (v1 <= v2)
      | _ -> assert false (* by assumption *)
    end
  | _ -> failwith "type mismatch: arguments must be of type integer."

let interp_binop_bool b1 b2 op =
  match b1, b2 with
  | VBool b1, VBool b2 ->
    begin match op with
      | OAnd -> VBool (b1 && b2)
      | OOr -> VBool (b1 || b2)
      | _ -> assert false (* by assumption *)
    end
  | _ -> failwith "type mismatch: arguments must be of type Boolean."

let interp_unop_bool b =
  match b with
  | VBool b ->
    if b then VBool false else VBool true
  | _ -> failwith "type mismatch: arguments must be of type Boolean."

let rec expr sigma = function
  | EValue (VBool b) -> VBool b
  | EValue (VInt n) -> VInt n
  | EVar x -> begin
      try get sigma x
      with Not_found -> failwith ("unbound variable: " ^ x ^ ".")
    end
  | EBinop (e1, (OAdd as op), e2)
  | EBinop (e1, (OMul as op), e2)
  | EBinop (e1, (OSub as op), e2)
  | EBinop (e1, (ODiv as op), e2)
  | EBinop (e1, (OMod as op), e2)
  | EBinop (e1, (OEq as op), e2)
  | EBinop (e1, (ONeq as op), e2)
  | EBinop (e1, (OLt as op), e2)
  | EBinop (e1, (OLe as op), e2)
  | EBinop (e1, (OGt as op), e2)
  | EBinop (e1, (OGe as op), e2) ->
    let v1 = expr sigma e1 in
    let v2 = expr sigma e2 in
    interp_binop_arith v1 v2 op
  | EBinop (e1, (OAnd as op), e2)
  | EBinop (e1, (OOr as op), e2) ->
    let b1 = expr sigma e1 in
    let b2 = expr sigma e2 in
    interp_binop_bool b1 b2 op
  | EUnop (UNeg, e) ->
    let b = expr sigma e in
    interp_unop_bool b
  | EValue (VPair (_, _)) -> assert false (* TODO -- Question 1.1 *)
  | EPair (_, _) -> assert false (* TODO -- Question 1.2 *)
  | EFst _ -> assert false (* TODO : Question 1.3 *)
  | ESnd _ -> assert false (* TODO Question 1.4 *)

let rec stmt sigma = function
  | SSkip -> ()
  | SAssign (x, e) ->
    let v = expr sigma e in
    set sigma x v
  | SIf (e, s1, s2) ->
    let b = expr sigma e in
    begin match b with
      | VBool b ->
        if b then stmt sigma s1
        else stmt sigma s2
      | VInt _ | VPair _ ->
        failwith "type mismatch: argument must be of type Boolean."
    end
  | SWhile (e, s) ->
    let b = expr sigma e in
    begin match b with
      | VBool b ->
        if b then begin
          stmt sigma s;
          stmt sigma (SWhile (e, s))
        end
      | VInt _ | VPair _ ->
        failwith "type mismatch: argument must be of type Boolean."
    end
  | SSeq (s1, s2) ->
    stmt sigma s1;
    stmt sigma s2
  | SRepeat (_, _) -> assert false (* TODO -- Question 2.1 *)
