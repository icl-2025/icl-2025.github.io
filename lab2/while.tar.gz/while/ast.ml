type value = VInt of int | VBool of bool | VPair of value * value

type op =
  | OAdd | OMul | OSub | ODiv | OMod
  | OEq  | ONeq | OLt  | OLe  | OGt | OGe
  | OAnd | OOr

type unop =
  | UNeg

type expr =
  | EValue of value
  | EVar of string
  | EBinop of expr * op * expr
  | EUnop of unop * expr
  | EPair of expr * expr
  | EFst of expr
  | ESnd of expr

type stmt =
  | SSkip
  | SAssign of string * expr
  | SIf of expr * stmt * stmt
  | SWhile of expr * stmt
  | SSeq of stmt * stmt
  | SRepeat of stmt * expr
