package whileLang;
import java.util.*;

public class Main {
    static String x = "x";
    static String y = "y";
    static String r = "r";

    static Expr varX = new Evar(x);
    static Expr varY = new Evar(y);
    static Expr varR = new Evar(r);

    static Value vint (int x) {
        return new Vint(x);
    }

    static Expr pair (Expr x, Expr y){
        return new Epair(x, y);
    }

    static Expr fst (Expr x) {
        return new Efst(x);
    }

    static Expr snd (Expr x) {
        return new Esnd(x);
    }

    static Stmt repeat (Stmt s, Expr e) {
        return new Srepeat(s, e);
    }

    static Stmt seq (Stmt s1, Stmt s2) {
        return new Sseq(s1, s2);
    }

    static Stmt assign (String x, Expr e) {
        return new Sassign(x, e);
    }

    static Expr one = new Ecte(1);

    static Expr zero = new Ecte(0);

    static Expr five = new Ecte(5);

    static Expr mul (Expr e1, Expr e2) {
        return new Ebinop(Binop.Mul, e1, e2);
    }

    static Expr sub (Expr e1, Expr e2) {
        return new Ebinop(Binop.Sub, e1, e2);
    }

    static Expr eq (Expr e1, Expr e2) {
        return new Ebinop(Binop.Eq, e1, e2);
    }

    static Stmt block (List<Stmt> s) {
        Stmt acc = null;

        for (Stmt x : s) {
            if (acc == null)
                acc = x;
            else
                acc = new Sseq(x, acc);
        }

        return acc;
    }

    static List<Stmt> body () {
        List<Stmt> l = new LinkedList<Stmt>();
        l.add(assign(x, fst(varR)));
        l.add(assign(y, snd(varR)));
        l.add(assign(y, mul(varY, varX)));
        l.add(assign(x, sub(varX, one)));
        l.add(assign(r, pair(varX, varY)));

        return l;
    }

    static Stmt repeatBody = block(body());

    static Expr repeatTest = eq(fst(varR), zero);

    /* p =def=

      r := (5, 1);
      repeat {
        x := fst r;
        y := snd r;
        y := y * x;
        x := x - 1;
        r := (x, y)
      } until fst r == 0 */

    static Stmt p =
        seq(assign(r, pair(five, one)),
            repeat(repeatBody, repeatTest));

    public static void main (String[] args) {
        Environment e = new Environment();

        Interp i = new Interp(e);

        Value p = e.env.get(r);
        Pair pp = p.asPair();

        System.out.println(pp.getSnd().asInt());
        assert pp.getSnd().asInt() == 120;
    }
}
