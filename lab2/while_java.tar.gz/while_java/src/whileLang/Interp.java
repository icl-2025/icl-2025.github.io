package whileLang;

class Interp implements Visitor {
    Environment env;

    public Interp () {
        env = new Environment();
    }

    public Interp (Environment env) {
        this.env = env;
    }

    public Value interp (Ecte e) {
        return new Vint(e.n);
    }

    public Value interp (Evar x) {
        Value v = env.env.get(x.id);
        if (v == null) {
            throw new Error("unbound variable " + x.id);
        }

        return v;
    }

    public Value interp (Eunop e) {
        Expr e = e.e;

        Value v = e.accept(this);

        if (v.asBool())
            return new Vbool(false);

        return new Vbool(true);
    }

    public Value interp (Ebinop e) {
        Binop op = e.op;
        Expr e1 = e.e1;
        Expr e2 = e.e2;

        Value v1 = e1.accept(this);
        Value v2 = e2.accept(this);

        switch(op) {
        case Add:
            return new Vint(v1.asInt() + v2.asInt());
        case Mul:
            return new Vint(v1.asInt() * v2.asInt());
        case Sub:
            return new Vint(v1.asInt() - v2.asInt());
        case Div:
            return new Vint(v1.asInt() / v2.asInt());
        case Mod:
            return new Vint(v1.asInt() % v2.asInt());
        case Eq:
            return new Vbool(v1.asInt() == v2.asInt());
        case Neq:
            return new Vbool(v1.asInt() != v2.asInt());
        case Lt:
            return new Vbool(v1.asInt() < v2.asInt());
        case Le:
            return new Vbool(v1.asInt() < v2.asInt());
        case Gt:
            return new Vbool(v1.asInt() < v2.asInt());
        case Ge:
            return new Vbool(v1.asInt() <= v2.asInt());
        case And:
            return new Vbool(v1.asBool() && v2.asBool());
        default:
            return new Vbool(v1.asBool() || v2.asBool());
        }
    }

    public Value interp (Epair e) {
        return null; // TODO : question 1.1
    }

    public Value interp (Efst e) {
        return null; // TODO
    }

    public Value interp (Esnd e) {
        return null; // TODO
    }

    public void interp (Sskip s) {}

    public void interp (Sassign s) {
        Value v = s.e.accept(this);
        env.env.put(s.x, v);
    }

    public void interp (Sif s) {
        Value b = s.e.accept(this);

        if (b.asBool())
            s.s1.accept(this);
        else
            s.s2.accept(this);
    }

    public void interp (Sseq s) {
        s.s1.accept(this);
        s.s2.accept(this);
    }

    public void interp (Swhile s) {
        Value b = s.e.accept(this);
        if (b.asBool()) {
            s.s.accept(this);
            this.interp(s);
        }
    }

    public void interp (Srepeat s) {
        // TODO
    }
}
