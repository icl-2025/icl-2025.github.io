package whileLang;

class Vbool extends Value {
    boolean b;

    public Vbool (boolean b) {
        this.b = b;
    }

    public int asInt () {
        throw new Error("Argument is not of type integer");
    }

    public boolean asBool () {
        return this.b;
    }

    public Pair asPair () {
        throw new Error("Argument is not of type pair");
    }
}
