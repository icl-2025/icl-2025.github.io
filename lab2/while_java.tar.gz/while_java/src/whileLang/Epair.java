package whileLang;

class Epair extends Expr {
    Expr e1, e2;

    public Epair () {}

    public Epair (Expr e1, Expr e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
