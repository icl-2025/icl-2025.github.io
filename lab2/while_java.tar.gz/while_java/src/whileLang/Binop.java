package whileLang;

enum Binop {
    Add, Mul, Sub, Div, Mod,
    Eq, Neq, Lt, Le, Gt, Ge,
    And, Or
}
