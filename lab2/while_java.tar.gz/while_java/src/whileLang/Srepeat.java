package whileLang;

class Srepeat extends Stmt {
    Stmt s;
    Expr e;

    public Srepeat (Stmt s, Expr e) {
        this.s = s;
        this.e = e;
    }

    public void accept (Visitor i) {
        i.interp(this);
    }
}
