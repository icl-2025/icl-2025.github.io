package whileLang;

abstract class Expr {
    abstract Value accept (Visitor i);
}
