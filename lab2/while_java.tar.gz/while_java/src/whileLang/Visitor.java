package whileLang;

interface Visitor {
    Value interp (Ecte e);
    Value interp (Evar e);
    Value interp (Ebinop e);
    Value interp (Eunop e);
    Value interp (Epair e);
    Value interp (Efst e);
    Value interp (Esnd e);
    void  interp (Sassign s);
    void  interp (Sif s);
    void  interp (Sseq s);
    void  interp (Sskip s);
    void  interp (Swhile s);
    void  interp (Srepeat s);
}
