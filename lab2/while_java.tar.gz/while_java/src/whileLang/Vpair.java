package whileLang;

class Vpair extends Value {
    Pair p;

    public Vpair (Pair p) {
        this.p = p;
    }

    public int asInt () {
        throw new Error("Argument is not of type integer");
    }

    public boolean asBool () {
        throw new Error("Argument is not of type Boolean");
    }

    public Pair asPair () {
        return this.p;
    }
}
