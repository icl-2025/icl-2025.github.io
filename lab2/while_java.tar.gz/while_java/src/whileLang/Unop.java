package whileLang;

enum Unop { Neg }
