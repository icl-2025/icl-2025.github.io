package whileLang;

class Vint extends Value {
    int n;

    public Vint (int n) {
        this.n = n;
    }

    public int asInt () {
        return this.n;
    }

    public boolean asBool () {
        throw new Error("Argument is not of type Boolean");
    }

    public Pair asPair () {
        throw new Error("Argument is not of type pair");
    }
}
