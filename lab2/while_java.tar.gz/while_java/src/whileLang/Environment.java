package whileLang;

import java.util.*;

class Environment {
    HashMap<String, Value> env;

    public Environment () {
        this.env = new HashMap<>();
    }
}
