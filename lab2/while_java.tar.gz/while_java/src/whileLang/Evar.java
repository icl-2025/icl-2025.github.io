package whileLang;

class Evar extends Expr {
    String id;

    public Evar (String id) {
        this.id = id;
    }

    public Value eval (Environment env) {
        Value v = env.env.get(id);
        if (v == null) {
            throw new Error("unbound variable " + id);
        }

        return v;
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
