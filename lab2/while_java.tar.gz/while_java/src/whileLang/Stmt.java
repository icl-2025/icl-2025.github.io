package whileLang;

abstract class Stmt {
    abstract void accept (Visitor i);
}
