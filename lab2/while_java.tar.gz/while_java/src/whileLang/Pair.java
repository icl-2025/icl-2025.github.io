package whileLang;

class Pair {
    Value v1, v2;

    public Pair () {}

    public Pair (Value v1, Value v2) {
        this.v1 = v1;
        this.v2 = v2;
    }

    public Pair (Pair p) {
        this(p.v1, p.v2);
    }

    public Value getFst () {
        return this.v1;
    }

    public Value getSnd () {
        return this.v2;
    }
}
