package whileLang;

class Ecte extends Expr {
    int n;

    public Ecte (int n) {
        this.n = n;
    }

    public Value eval (Environment env) {
        return new Vint(n);
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
