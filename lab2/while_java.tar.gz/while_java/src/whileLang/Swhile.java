package whileLang;

class Swhile extends Stmt {
    Expr e;
    Stmt s;

    public Swhile (Expr e, Stmt s) {
        this.e = e;
        this.s = s;
    }

    public void accept (Visitor i) {
        i.interp(this);
    }
}
