package whileLang;

class Eunop extends Expr {
    Expr e;

    public Eunop (Expr e) {
        this.e = e;
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
