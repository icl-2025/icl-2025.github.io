package whileLang;

class Ebinop extends Expr {
    Binop op;
    Expr e1, e2;

    public Ebinop (Binop op, Expr e1, Expr e2) {
        this.op = op;
        this.e1 = e1;
        this.e2 = e2;
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
