package whileLang;

class Efst extends Expr {
    Expr e;

    public Efst () {}

    public Efst (Expr e) {
        this.e = e;
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
