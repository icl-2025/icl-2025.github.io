package whileLang;

class Sassign extends Stmt {
    String x;
    Expr e;

    public Sassign (String x, Expr e) {
        this.x = x;
        this.e = e;
    }

    public void accept (Visitor i) {
        i.interp(this);
    }
}
