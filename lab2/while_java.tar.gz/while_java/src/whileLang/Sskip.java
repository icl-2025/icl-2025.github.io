package whileLang;

class Sskip extends Stmt {
    public Sskip () {}

    public void eval (Environment env) {}

    public void accept (Visitor i) {
        i.interp(this);
    }
}
