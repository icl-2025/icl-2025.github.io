package whileLang;

class Esnd extends Expr {
    Expr e;

    public Esnd () {}

    public Esnd (Expr e) {
        this.e = e;
    }

    public Value accept (Visitor i) {
        return i.interp(this);
    }
}
