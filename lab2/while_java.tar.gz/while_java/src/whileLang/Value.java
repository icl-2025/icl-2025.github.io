package whileLang;

abstract class Value {
    abstract int asInt ();
    abstract boolean asBool ();
    abstract Pair asPair ();
}
