
(* -------------------------------------------------------------------------- *)
(* ----------------------- DEFINITIONS OF MUSIC SCORES ---------------------- *)
(* -------------------------------------------------------------------------- *)

type note = C | D | E | F | G | A | B
type pitch = { note : note; octave : int }
type duration = Full | Half | Quarter | Eighth | Sixteenth
type symbol = Note of duration * pitch | Rest of duration
type score = { symbols : symbol list;  tempo : int }

let o1_frequency t = match t with
  | C -> 32.70
  | D -> 36.71
  | E -> 41.20
  | F -> 43.65
  | G -> 49.
  | A -> 55.
  | B -> 61.74

let frequency p =
  let f0 = o1_frequency p.note in
  f0 *. (2. ** float p.octave)

let duration d t =
  let t = 60. /. (float_of_int t) in
  match d with
  | Sixteenth -> t /. 4.
  | Eighth    -> t /. 2.
  | Quarter   -> t +. 0.0001
  | Half      -> t *. 2.
  | Full      -> t *. 4.

let df_of_symbol s tp =
  match s with
  | Rest d -> (duration d tp, 0.)
  | Note (d, f) -> (duration d tp, frequency f)

(* -------------------------------------------------------------------------- *)
(* ------------------------------ PLAYING SOUNDS  --------------------------- *)
(* -------------------------------------------------------------------------- *)

let play_sound s tp =
  let (d, f) = df_of_symbol s tp in
  let pid = Unix.create_process
      "/usr/bin/play"
      [|"play"; "-r"; "44100"; "-n"; "synth"; string_of_float d; "sin"; string_of_float f |]
      Unix.stdin Unix.stdout Unix.stderr in
  let _ = Unix.waitpid [] pid in ()

let play_score sc =
  List.iter (fun s -> play_sound s sc.tempo) sc.symbols

let increase_pitch_octave p =
  { p with octave = p.octave + 1 }

let decrease_pitch_octave p =
  { p with octave = p.octave - 1 }

let change_octave (f: pitch -> pitch) (s: symbol) =
  match s with
  | Note (d, p) -> Note (d, f p)
  | Rest d -> Rest d

let increase_octave = change_octave increase_pitch_octave
let decrease_octave = change_octave decrease_pitch_octave

let increase_duration (s: symbol) =
  let increase (d: duration) =
    match d with
    | Full -> Full
    | Half -> Full
    | Quarter -> Half
    | Eighth -> Quarter
    | Sixteenth -> Eighth in
  match s with
  | Note (d, p) -> Note (increase d, p)
  | Rest d -> Rest d

let decrease_duration (s: symbol) =
  match s with
  | Note (_, p) -> Note (Sixteenth, p)
  | Rest d -> Rest d

let file fname =
  let cin = open_in fname in
  let text = ref [] in
  let rec read_loop () =
    try
      let line = input_line cin in
      text := line :: !text;
      read_loop ()
    with End_of_file -> !text in
  assert false (* TODO *)

let () =
  play_score (file Sys.argv.(1))
