let copy f1 f2 =
  assert false (* TODO *)

let () =
  copy Sys.argv.(1) Sys.argv.(2)
