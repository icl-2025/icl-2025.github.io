type quad =
  | White
  | Black
  | Node of quad * quad * quad * quad

let rec draw x y w = function
  | White -> ()
  | Black -> Graphics.fill_rect x y w w
  | Node (q1, q2, q3, q4) ->
    let w = w / 2 in
    draw x y w q1;
    draw (x + w) y w q2;
    draw (x + w) (y + w) w q3;
    draw x (y + w) w q4

let rec checker_board n =
  assert false (* TODO *)

let node (q1, q2, q3, q4) =
  assert false (* TODO *)

let rec rotate q =
  assert false (* TODO *)

let rec mirror q =
  assert false (* TODO *)

let rec unparse q =
  assert false (* TODO *)

let parse s =
  assert false (* TODO *)

let () =
  Graphics.open_graph " 3x3";
  let board = checker_board 3 in
  draw 0 0 256 board;
  ignore (Graphics.read_key ());
  Graphics.clear_graph ();
  let m_board = mirror board in
  draw 0 0 256 (m_board);
  ignore (Graphics.read_key ());
  Graphics.clear_graph ();
  draw 0 0 256 (rotate m_board);
  ignore (Graphics.read_key ());
  Graphics.clear_graph ()

let () =
  let board = checker_board 3 in
  Format.eprintf "%s@." (unparse board)

let () =
  let s = "0101" in
  let q = parse s in
  Graphics.open_graph " 3x3";
  draw 0 0 256 q;
  ignore (Graphics.read_key ())

let () =
  let s =
    "0101010101010101010101010101010101010101010101010101010101010101"
  in
  let q = parse s in
  let s' = unparse q in
  assert (s = s');
  Graphics.open_graph " 3x3";
  draw 0 0 256 q;
  ignore (Graphics.read_key ())
