let lines =
  let lines = ref [] in
  let rec loop () =
    assert false (* TODO *) in
  try
    loop ()
  with End_of_file -> assert false (* TODO *)

let print l =
  assert false (* TODO *)

let () =
  print lines
